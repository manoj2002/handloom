package com.handloom.authentication;

import java.util.ArrayList;
import java.util.List;

public class cart {
	public static List<manufacturer> cartprod;
	static {
		cartprod=new ArrayList<manufacturer>();
	}
}
